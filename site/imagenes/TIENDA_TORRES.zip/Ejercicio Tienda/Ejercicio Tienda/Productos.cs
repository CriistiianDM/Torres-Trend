﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Ejercicio_Tienda
{
    internal class Productos
    {
        private int Huevos;
        private int Lentejas;
        private int Pollo;
        private int papa;
        private int carne;
        private int Pan;
        private int arroz;
        private int ValorUnitario;
        private int Cantidad;
        private int ValorTotal;
        private string Producto;
        private string Cambio;
        private string ConexionDB;

        
   

    

    public void SetHuevos(int H)
        {
            Huevos = H;
        }

        public int GetHuevos()
        {
            return  Huevos ;
        }

        public void SetLentejas(int L)
        {
            Lentejas = L;
        }

        public int GetLentejas()
        {
            return Lentejas ;
        }

        public  void  SetPollo(int P)
        {
            Pollo = P;
        }

        public int GetPollo()
        {
            return Pollo;
        }

        public void SetPapa(int PP)
        {
            papa = PP;
        }

        public int GetPapa()
        {
            return papa;
        }
        public void SetCarne(int ca)
        {
            carne = ca;
        }

        public  int GetCarne()
        {
            return carne;
        }

        public void SetPan(int BP)
        {
            Pan = BP;
        }

        public int GetPan()
        {
            return Pan;
        }
        public void SetArroz(int A)
        {
            arroz = A;
        }
        public int GetArroz()
        {
            return arroz;
        }
        public void SetValorUnitario(int VU)
        {
            ValorUnitario = VU;
        }
        public int GetValorUnitario()
        {
            return ValorUnitario;
        }
        public void SetCantidad(int C)
        {
            Cantidad = C;
        }
        public int GetCantidad()
        {
            return Cantidad;
        }
        public void SetValorTotal(int VT)
        {
            ValorTotal = VT;
        }
        public int GetValorTotal()
        {
            return ValorTotal;
        }
        public void SetProducto(string P)
        {
            Producto = P;
        }
        public string GetProducto() { return Producto; }
        public void SetCambio(string C)
        {
            Cambio = C;
        }
        public string GetCambio()
        {
            return Cambio;
        }
        public void SetConexionDB(string C)
        {
            ConexionDB = C;
        }
        public string GetConexionDB()
        {
            return ConexionDB;
        }

        public Productos()
        {
            Huevos = 200;
            Pollo = 30000;
            papa = 1000;
            carne = 2300;
            Pan = 2000;
            arroz = 3000;
            Cambio = "";

        }
    }
}
