﻿namespace Ejercicio_Tienda
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt_Pagar = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btn_Comprar = new Button();
            btn_Sumar = new Button();
            txt_ValorTotal = new TextBox();
            txt_Cambio = new TextBox();
            dataGridView1 = new DataGridView();
            Productos = new DataGridViewTextBoxColumn();
            ValorUnitario = new DataGridViewTextBoxColumn();
            Cantidad = new DataGridViewTextBoxColumn();
            ValorTotal = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // txt_Pagar
            // 
            txt_Pagar.Location = new Point(808, 186);
            txt_Pagar.Name = "txt_Pagar";
            txt_Pagar.Size = new Size(150, 31);
            txt_Pagar.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(821, 37);
            label1.Name = "label1";
            label1.Size = new Size(94, 25);
            label1.TabIndex = 3;
            label1.Text = "Valor Total";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(830, 143);
            label2.Name = "label2";
            label2.Size = new Size(56, 25);
            label2.TabIndex = 4;
            label2.Text = "Pagar";
            // 
            // btn_Comprar
            // 
            btn_Comprar.Location = new Point(811, 271);
            btn_Comprar.Name = "btn_Comprar";
            btn_Comprar.Size = new Size(112, 34);
            btn_Comprar.TabIndex = 5;
            btn_Comprar.Text = "Comprar";
            btn_Comprar.UseVisualStyleBackColor = true;
            btn_Comprar.Click += btn_Comprar_Click;
            // 
            // btn_Sumar
            // 
            btn_Sumar.Location = new Point(978, 68);
            btn_Sumar.Name = "btn_Sumar";
            btn_Sumar.Size = new Size(184, 34);
            btn_Sumar.TabIndex = 6;
            btn_Sumar.Text = "Sumatoria Total";
            btn_Sumar.UseVisualStyleBackColor = true;
            btn_Sumar.Click += btn_Sumar_Click;
            // 
            // txt_ValorTotal
            // 
            txt_ValorTotal.Location = new Point(805, 91);
            txt_ValorTotal.Name = "txt_ValorTotal";
            txt_ValorTotal.Size = new Size(150, 31);
            txt_ValorTotal.TabIndex = 7;
            txt_ValorTotal.TextChanged += txt_ValorTotal_TextChanged;
            // 
            // txt_Cambio
            // 
            txt_Cambio.Location = new Point(815, 329);
            txt_Cambio.Multiline = true;
            txt_Cambio.Name = "txt_Cambio";
            txt_Cambio.Size = new Size(262, 140);
            txt_Cambio.TabIndex = 8;
            txt_Cambio.TextChanged += txt_Cambio_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Productos, ValorUnitario, Cantidad, ValorTotal });
            dataGridView1.Location = new Point(12, 57);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(694, 267);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Productos
            // 
            Productos.HeaderText = "Productos";
            Productos.MinimumWidth = 8;
            Productos.Name = "Productos";
            Productos.Width = 150;
            // 
            // ValorUnitario
            // 
            ValorUnitario.HeaderText = "ValorUnitario";
            ValorUnitario.MinimumWidth = 8;
            ValorUnitario.Name = "ValorUnitario";
            ValorUnitario.Width = 150;
            // 
            // Cantidad
            // 
            Cantidad.HeaderText = "Cantidad";
            Cantidad.MinimumWidth = 8;
            Cantidad.Name = "Cantidad";
            Cantidad.Width = 150;
            // 
            // ValorTotal
            // 
            ValorTotal.HeaderText = "ValorTotal";
            ValorTotal.MinimumWidth = 8;
            ValorTotal.Name = "ValorTotal";
            ValorTotal.Width = 150;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1261, 481);
            Controls.Add(txt_Cambio);
            Controls.Add(txt_ValorTotal);
            Controls.Add(btn_Sumar);
            Controls.Add(btn_Comprar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt_Pagar);
            Controls.Add(dataGridView1);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txt_Pagar;
        private Label label1;
        private Label label2;
        private Button btn_Comprar;
        private Button btn_Sumar;
        private TextBox txt_ValorTotal;
        private TextBox txt_Cambio;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Productos;
        private DataGridViewTextBoxColumn ValorUnitario;
        private DataGridViewTextBoxColumn Cantidad;
        private DataGridViewTextBoxColumn ValorTotal;
    }
}