﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Ejercicio_Tienda
{
    public class Controlador
    {
        private string connectionString = "Server=(localdb)\\intento_final; Database=;Trusted_Connection=True;";
        Productos Product = new Productos();
        List<Productos> Listado = new List<Productos>();


        public string ValorFinal(string producto, string cantidad)
        {
            Productos Productito = new Productos();
            int Valor = 0;

            switch (producto)
            {
                case "Huevos":
                    Productito.SetProducto("Huevos");
                    Productito.SetValorUnitario(500);
                    Valor = Productito.GetHuevos() * int.Parse(cantidad); ;
                    break;

                case "arroz":
                    Productito.SetProducto("Lentejas");
                    Productito.SetValorUnitario(3000);
                    Valor = Productito.GetArroz() * int.Parse(cantidad);
                    break;

                case "papa":
                    Productito.SetProducto("papa");
                    Productito.SetValorUnitario(1000);
                    Valor = Productito.GetPapa() * int.Parse(cantidad);
                    break;

                case "Pollo":
                    Productito.SetProducto("Pollo");
                    Productito.SetValorUnitario(30000);
                    Valor = Productito.GetPollo() * int.Parse(cantidad);
                    break;

                case "carne":
                    Productito.SetProducto("carne");
                    Productito.SetValorUnitario(2300);
                    Valor = Productito.GetCarne() * int.Parse(cantidad);
                    break;

                case "Pan":
                    Productito.SetProducto("Pan");
                    Productito.SetValorUnitario(2000);
                    Valor = Productito.GetPan() * int.Parse(cantidad);
                    break;
            }

            Productito.SetCantidad(int.Parse(cantidad));
            Productito.SetValorTotal(Valor);
            Listado.Add(Productito);
            GuardarEnBaseDeDatos(Productito);

            return Valor.ToString();
        }

        public string Cambio(int pago, int ValorTotal)
        {
            StringBuilder cambio = new StringBuilder();
            int[] Billetes = { 50000, 20000, 10000, 5000, 2000, 1000 };
            int[] Monedas = { 500, 200, 100, 50 };

            int CambioCompleto = pago - ValorTotal;

            foreach (int valor in Billetes.Concat(Monedas))
            {

                int cantidad = CambioCompleto / valor;
                if (cantidad > 0)
                {
                    cambio.AppendLine($" {cantidad} de  {valor}");
                    CambioCompleto %= valor;
                }

            }

            return cambio.ToString().Trim();

        }

        public void CargarDatos(DataGridView dgv)
        {
            dgv.Rows.Clear();
            foreach (var producto in Listado)
            {
                dgv.Rows.Add(producto.GetProducto(), producto.GetValorUnitario(), producto.GetCantidad(), producto.GetValorTotal());
            }
        }
        private void GuardarEnBaseDeDatos(Productos producto)
        {
            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                conexion.Open();
                string query = "INSERT INTO Tienda(Productos,Valor_Unitario,Cantidad,valor_total) VALUES (@Productos, @Valor_Unitario, @Cantidad, @valor_total)";

                using (SqlCommand comando = new SqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@Productos", producto.GetProducto());
                    comando.Parameters.AddWithValue("@Valor_Unitario", producto.GetValorUnitario());
                    comando.Parameters.AddWithValue("@Cantidad", producto.GetCantidad());
                    comando.Parameters.AddWithValue("@valor_total", producto.GetValorTotal());


                    comando.ExecuteNonQuery();
                }
            }

        }



        }
    }
