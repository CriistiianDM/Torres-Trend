﻿namespace Ejercicio_Tienda
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ImagenProductos = new PictureBox();
            txt_Precio = new TextBox();
            label1 = new Label();
            label2 = new Label();
            ListadoProductos = new ComboBox();
            ListadoCantidades = new ComboBox();
            compra = new Label();
            btn_Comprar = new Button();
            Btn_Menu = new Button();
            txt_ValorTotal = new TextBox();
            label4 = new Label();
            txt_ValorFinal = new TextBox();
            ((System.ComponentModel.ISupportInitialize)ImagenProductos).BeginInit();
            SuspendLayout();
            // 
            // ImagenProductos
            // 
            ImagenProductos.Location = new Point(526, 66);
            ImagenProductos.Name = "ImagenProductos";
            ImagenProductos.Size = new Size(358, 247);
            ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
            ImagenProductos.TabIndex = 1;
            ImagenProductos.TabStop = false;
            ImagenProductos.Click += ImagenProductos_Click_1;
            // 
            // txt_Precio
            // 
            txt_Precio.Location = new Point(354, 116);
            txt_Precio.Name = "txt_Precio";
            txt_Precio.Size = new Size(150, 31);
            txt_Precio.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaption;
            label1.Location = new Point(82, 77);
            label1.Name = "label1";
            label1.Size = new Size(115, 25);
            label1.TabIndex = 3;
            label1.Text = "PRODUCTOS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaption;
            label2.Location = new Point(394, 83);
            label2.Name = "label2";
            label2.Size = new Size(66, 25);
            label2.TabIndex = 4;
            label2.Text = "VALOR";
            // 
            // ListadoProductos
            // 
            ListadoProductos.FormattingEnabled = true;
            ListadoProductos.Items.AddRange(new object[] { "Huevos", "arroz", "Pan", "Pollo", "papa", "carne" });
            ListadoProductos.Location = new Point(82, 116);
            ListadoProductos.Name = "ListadoProductos";
            ListadoProductos.Size = new Size(182, 33);
            ListadoProductos.TabIndex = 5;
            ListadoProductos.SelectedIndexChanged += ListadoProductos_SelectedIndexChanged_1;
            // 
            // ListadoCantidades
            // 
            ListadoCantidades.FormattingEnabled = true;
            ListadoCantidades.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            ListadoCantidades.Location = new Point(70, 215);
            ListadoCantidades.Name = "ListadoCantidades";
            ListadoCantidades.Size = new Size(182, 33);
            ListadoCantidades.TabIndex = 6;
            ListadoCantidades.SelectedIndexChanged += ListadoCantidades_SelectedIndexChanged;
            // 
            // compra
            // 
            compra.AutoSize = true;
            compra.BackColor = SystemColors.ActiveCaption;
            compra.Location = new Point(129, 177);
            compra.Name = "compra";
            compra.Size = new Size(83, 25);
            compra.TabIndex = 8;
            compra.Text = "Cantidad";
            // 
            // btn_Comprar
            // 
            btn_Comprar.BackColor = SystemColors.ActiveCaption;
            btn_Comprar.Location = new Point(100, 285);
            btn_Comprar.Name = "btn_Comprar";
            btn_Comprar.Size = new Size(112, 34);
            btn_Comprar.TabIndex = 11;
            btn_Comprar.Text = "Valor Final";
            btn_Comprar.UseVisualStyleBackColor = false;
            btn_Comprar.Click += btn_Comprar_Click_1;
            // 
            // Btn_Menu
            // 
            Btn_Menu.BackColor = SystemColors.ActiveCaption;
            Btn_Menu.Location = new Point(911, 30);
            Btn_Menu.Name = "Btn_Menu";
            Btn_Menu.Size = new Size(202, 34);
            Btn_Menu.TabIndex = 16;
            Btn_Menu.Text = "Menu de la Compra";
            Btn_Menu.UseVisualStyleBackColor = false;
            Btn_Menu.Click += Btn_Menu_Click;
            // 
            // txt_ValorTotal
            // 
            txt_ValorTotal.Location = new Point(180, 434);
            txt_ValorTotal.Name = "txt_ValorTotal";
            txt_ValorTotal.Size = new Size(150, 31);
            txt_ValorTotal.TabIndex = 17;
            txt_ValorTotal.TextChanged += txt_ValorTotal_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(70, 451);
            label4.Name = "label4";
            label4.Size = new Size(61, 25);
            label4.TabIndex = 18;
            label4.Text = "TOTAL";
            // 
            // txt_ValorFinal
            // 
            txt_ValorFinal.Location = new Point(343, 215);
            txt_ValorFinal.Name = "txt_ValorFinal";
            txt_ValorFinal.Size = new Size(150, 31);
            txt_ValorFinal.TabIndex = 19;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1182, 506);
            Controls.Add(txt_ValorFinal);
            Controls.Add(label4);
            Controls.Add(txt_ValorTotal);
            Controls.Add(Btn_Menu);
            Controls.Add(btn_Comprar);
            Controls.Add(compra);
            Controls.Add(ListadoCantidades);
            Controls.Add(ListadoProductos);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt_Precio);
            Controls.Add(ImagenProductos);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)ImagenProductos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox ImagenProductos;
        private TextBox txt_Precio;
        private Label label1;
        private Label label2;
        private ComboBox ListadoProductos;
        private ComboBox ListadoCantidades;
        private Label compra;
        private Button btn_Comprar;
        private Button Btn_Menu;
        private TextBox txt_ValorTotal;
        private Label label4;
        private TextBox txt_ValorFinal;
    }
}
