using System.Windows.Forms;

namespace Ejercicio_Tienda
{
    public partial class Form1 : Form
    {
        Controlador Control = new Controlador();
        Productos Precio = new Productos();


        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ImagenProductos_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }



        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_Cambio_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ListadoProductos_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string selecion = ListadoProductos.SelectedItem.ToString();

            switch (selecion)
            {

                case "Huevos":
                    PictureBox Imagen = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.huevos));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;

                case "carne":
                    PictureBox Imagen2 = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.carne));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;

                case "Pollo":
                    PictureBox Imagen3 = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.pollo));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;

                case "papa":
                    PictureBox Imagen4 = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.papa));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;

                case "arroz":
                    PictureBox Imagen5 = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.arroz));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;

                case "Pan":
                    PictureBox Imagen6 = new PictureBox();
                    ImagenProductos.Image = Image.FromStream(new MemoryStream(Properties.Resources.pan));
                    ImagenProductos.SizeMode = PictureBoxSizeMode.Zoom;
                    break;
            }

            switch (selecion)
            {
                case "Huevos":
                    txt_Precio.Text = Precio.GetHuevos().ToString();
                    break;

                case "carne":
                    txt_Precio.Text = Precio.GetCarne().ToString();
                    break;

                case "papa":
                    txt_Precio.Text = Precio.GetPapa().ToString();
                    break;

                case "Pollo":
                    txt_Precio.Text = Precio.GetPollo().ToString();
                    break;

                case "arroz":
                    txt_Precio.Text = Precio.GetArroz().ToString();
                    break;

                case "Pan":
                    txt_Precio.Text = Precio.GetPan().ToString();
                    break;
            }
        }

        private void btn_Comprar_Click_1(object sender, EventArgs e)
        {
            string Producto = ListadoProductos.SelectedItem.ToString();
            string Cantidad = ListadoCantidades.SelectedItem.ToString();
            txt_ValorTotal.Text = Control.ValorFinal(Producto, Cantidad);
        }



        private void ImagenProductos_Click_1(object sender, EventArgs e)
        {

        }

        private void txt_ValorFinal_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_ValorFinal_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void Btn_Menu_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(Control);
            form2.Show();

            form2.CargarTabla();
        }

        private void txt_ValorTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void ListadoCantidades_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

