﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_Tienda
{
    public partial class Form2 : Form
    {
        Productos Product = new Productos();
        private Controlador Control;
        public Form2(Controlador control)
        {
            InitializeComponent();
            this.Control = control;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // Código de carga del formulario
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        public void CargarTabla()
        {
            Control.CargarDatos(dataGridView1);
        }



        private void btn_Sumar_Click(object sender, EventArgs e)
        {
            ActualizarValorTotal();
        }

        private void txt_ValorTotal_TextChanged(object sender, EventArgs e)
        {
            ActualizarValorTotal();
        }

        private void btn_Comprar_Click(object sender, EventArgs e)
        {
            int pago = int.Parse(txt_Pagar.Text);
            int valorFinal = int.Parse(txt_ValorTotal.Text);

            txt_Cambio.Text = Control.Cambio(pago, valorFinal);
        }
        private void ActualizarValorTotal()
        {
            decimal sumaTotal = 0;

            foreach (DataGridViewRow fila in dataGridView1.Rows)
            {
                if (fila.Cells["ValorTotal"].Value != null)
                {
                    sumaTotal += Convert.ToDecimal(fila.Cells["ValorTotal"].Value);
                }
            }

            txt_ValorTotal.Text = sumaTotal.ToString();
        }

        private void txt_Cambio_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


